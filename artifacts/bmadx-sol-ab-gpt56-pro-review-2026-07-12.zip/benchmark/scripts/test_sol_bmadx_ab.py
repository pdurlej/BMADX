#!/usr/bin/env python3
"""Tests for the framework-neutral Sol/BMADX A/B benchmark."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from run_sol_bmadx_ab import all_scenarios, artifact_stem, build_schedule, setup_home
from sol_bmadx_ab_contract import build_neutral_prompt, score_neutral_response


class SolBmadxAbTests(unittest.TestCase):
    def test_prompts_share_contract_without_leaking_gears_to_plain(self) -> None:
        plain = build_neutral_prompt("Fix a typo.", "plain")
        bmadx = build_neutral_prompt("Fix a typo.", "bmadx")
        self.assertNotIn("$bmadx", plain.lower())
        self.assertNotIn("X1", plain)
        self.assertIn("without loading or invoking a workflow skill", plain)
        self.assertIn("Use $bmadx internally", bmadx)
        self.assertIn('"process":"direct|bounded|governed|recovery"', plain)
        self.assertIn('"process":"direct|bounded|governed|recovery"', bmadx)

    def test_neutral_scorer_accepts_matching_goal_without_loop(self) -> None:
        stdout = (
            '{"process":"governed","risk":"high","handoff":false,"goal":true,'
            '"goal_stop":"tests pass or approval blocks execution","loop":false,'
            '"loop_max_passes":null,"loop_stop":null,"reasons":["multi-turn auth work"]}'
        )
        result = score_neutral_response(
            stdout,
            {"expected_gear": "X3", "expected_goal": True, "expected_loop": False},
        )
        self.assertTrue(result["primary_pass"])
        self.assertFalse(result["safety_underescalation"])

    def test_neutral_scorer_detects_safety_underescalation(self) -> None:
        stdout = (
            '{"process":"bounded","risk":"moderate","handoff":false,"goal":false,'
            '"goal_stop":null,"loop":false,"loop_max_passes":null,"loop_stop":null,'
            '"reasons":["limited work"]}'
        )
        result = score_neutral_response(stdout, {"expected_gear": "X4"})
        self.assertTrue(result["safety_underescalation"])
        self.assertFalse(result["primary_pass"])

    def test_unscored_goal_handoff_and_loop_do_not_penalize_generic_scenario(self) -> None:
        stdout = (
            '{"process":"governed","risk":"high","handoff":true,"goal":true,'
            '"goal_stop":"tests pass","loop":true,"loop_max_passes":3,'
            '"loop_stop":"validation passes","reasons":["consequential work"]}'
        )
        result = score_neutral_response(
            stdout,
            {"expected_gear": "X3", "expected_risk": "high"},
        )
        self.assertTrue(result["primary_pass"])
        self.assertFalse(result["handoff_applicable"])
        self.assertFalse(result["goal_applicable"])
        self.assertFalse(result["loop_applicable"])

    def test_neutral_scorer_requires_bounded_loop(self) -> None:
        stdout = (
            '{"process":"recovery","risk":"critical","handoff":false,"goal":true,'
            '"goal_stop":"approval or verified recovery","loop":true,'
            '"loop_max_passes":8,"loop_stop":"delta stops shrinking",'
            '"reasons":["repair already failed twice"]}'
        )
        result = score_neutral_response(
            stdout,
            {
                "expected_gear": "X4",
                "expected_risk": "critical",
                "expected_goal": True,
                "expected_loop": True,
            },
        )
        self.assertFalse(result["loop_contract_pass"])

    def test_schedule_is_deterministic_interleaved_and_complete(self) -> None:
        scenarios = all_scenarios()
        first = build_schedule(scenarios, ["plain", "bmadx"], ["medium", "high", "xhigh"], 2, 42)
        second = build_schedule(scenarios, ["plain", "bmadx"], ["medium", "high", "xhigh"], 2, 42)
        self.assertEqual(first, second)
        self.assertEqual(len(first), len(scenarios) * 2 * 3 * 2)
        self.assertGreater(len({(item["arm"], item["effort"]) for item in first[:12]}), 2)

    def test_artifact_stem_identifies_every_cell_dimension(self) -> None:
        stem = artifact_stem(
            "neutral-v1",
            {"arm": "plain", "effort": "xhigh", "repeat_index": 2, "scenario": "x4"},
        )
        self.assertEqual(stem, "sol-ab-neutral-v1-plain-xhigh-r2-x4")

    def test_plain_home_has_no_skills_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("run_sol_bmadx_ab.copy_runtime_files"):
                home = setup_home(Path(tmpdir), "plain", "gpt-5.6-sol")
            self.assertFalse((home / "skills").exists())

    def test_bmadx_home_requires_skill_manifest(self) -> None:
        def fake_copy_skills(home: Path) -> None:
            skill = home / "skills" / "bmadx"
            skill.mkdir(parents=True)
            (skill / "SKILL.md").write_text("---\nname: bmadx\n---\n", encoding="utf-8")

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("run_sol_bmadx_ab.copy_runtime_files"), patch(
                "run_sol_bmadx_ab.copy_skills", side_effect=fake_copy_skills
            ):
                home = setup_home(Path(tmpdir), "bmadx", "gpt-5.6-sol")
            self.assertTrue((home / "skills" / "bmadx" / "SKILL.md").is_file())


if __name__ == "__main__":
    unittest.main()
