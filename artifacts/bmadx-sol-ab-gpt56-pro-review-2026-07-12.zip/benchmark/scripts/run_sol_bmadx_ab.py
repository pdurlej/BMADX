#!/usr/bin/env python3
"""Run a matched, framework-neutral Sol plain-vs-BMADX benchmark."""

from __future__ import annotations

import argparse
import json
import random
import subprocess
import tempfile
import time
from collections import defaultdict
from datetime import date
from pathlib import Path

from bmadx_benchmark_scenarios import (
    BOUNDARY_SCENARIOS,
    CORE_SCENARIOS,
    GOAL_LOOP_SCENARIOS,
    HANDOFF_SCENARIOS,
    NON_TECH_SCENARIOS,
)
from bmadx_benchmark_validation import parse_token_count, sanitize_stderr
from run_bmadx_benchmark import (
    BENCHMARK_ROOT,
    RAW_ROOT,
    benchmark_env,
    build_codex_command,
    copy_runtime_files,
    copy_skills,
    repo_relative,
    warmup_profile,
    write_config,
    write_healthy_bmad_fixture,
)
from sol_bmadx_ab_contract import build_neutral_prompt, score_neutral_response, task_from_scenario


DEFAULT_MODEL = "gpt-5.6-sol"
DEFAULT_EFFORTS = ("medium", "high", "xhigh")
DEFAULT_ARMS = ("plain", "bmadx")


def all_scenarios() -> dict[str, dict]:
    merged: dict[str, dict] = {}
    for group in (
        CORE_SCENARIOS,
        BOUNDARY_SCENARIOS,
        NON_TECH_SCENARIOS,
        HANDOFF_SCENARIOS,
        GOAL_LOOP_SCENARIOS,
    ):
        merged.update(group)
    expected_risks = {
        "x1": "low",
        "x2": "moderate",
        "x3": "moderate",
        "x4": "high",
        "x2x3-boundary": "moderate",
        "pricing-copy": "low",
        "onboarding-email": "low",
        "google-login": "high",
        "subscription-billing": "high",
        "delete-inactive-users": "high",
        "messy-migration-incident": "critical",
        "x3-auth-review-handoff": "high",
        "x4-migration-review-handoff": "critical",
        "goal-x3-auth-cleanup": "high",
        "loop-x4-migration-repair": "critical",
    }
    for scenario, expected_risk in expected_risks.items():
        merged[scenario] = dict(merged[scenario], expected_risk=expected_risk)
    return merged


def comma_choices(raw: str, allowed: tuple[str, ...], label: str) -> list[str]:
    values = [value.strip() for value in raw.split(",") if value.strip()]
    unknown = sorted(set(values) - set(allowed))
    if unknown:
        raise argparse.ArgumentTypeError(f"Unknown {label}: {', '.join(unknown)}")
    return values or list(allowed)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--efforts", default=",".join(DEFAULT_EFFORTS))
    parser.add_argument("--arms", default=",".join(DEFAULT_ARMS))
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--seed", type=int, default=560712)
    parser.add_argument("--date-stamp", default=str(date.today()))
    parser.add_argument("--run-label", default="neutral-v1")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args(argv)
    try:
        args.efforts = comma_choices(args.efforts, DEFAULT_EFFORTS, "efforts")
        args.arms = comma_choices(args.arms, DEFAULT_ARMS, "arms")
    except argparse.ArgumentTypeError as exc:
        parser.error(str(exc))
    if args.repeat < 1:
        parser.error("--repeat must be >= 1")
    if not args.run_label.replace("-", "").replace("_", "").isalnum():
        parser.error("--run-label must contain only letters, digits, hyphens, or underscores")
    return args


def build_schedule(
    scenarios: dict[str, dict], arms: list[str], efforts: list[str], repeat: int, seed: int
) -> list[dict]:
    schedule = [
        {"arm": arm, "effort": effort, "repeat_index": repeat_index, "scenario": scenario}
        for repeat_index in range(1, repeat + 1)
        for scenario in scenarios
        for effort in efforts
        for arm in arms
    ]
    random.Random(seed).shuffle(schedule)
    return schedule


def artifact_stem(run_label: str, item: dict) -> str:
    return (
        f"sol-ab-{run_label}-{item['arm']}-{item['effort']}"
        f"-r{item['repeat_index']}-{item['scenario']}"
    )


def summary_path(date_stamp: str, run_label: str) -> Path:
    return BENCHMARK_ROOT / f"ab-summary-{date_stamp}-gpt-5-6-sol-{run_label}.json"


def setup_home(root: Path, arm: str, model: str) -> Path:
    home = root / f"codex-home-{arm}"
    write_config(home, model, DEFAULT_EFFORTS[0])
    copy_runtime_files(home)
    if arm == "bmadx":
        copy_skills(home)
        if not (home / "skills" / "bmadx" / "SKILL.md").is_file():
            raise RuntimeError("BMADX treatment home is missing skills/bmadx/SKILL.md")
    elif (home / "skills").exists():
        raise RuntimeError("Plain control home unexpectedly contains skills")
    return home


def cell_summary(cases: list[dict]) -> dict:
    count = len(cases)
    return {
        "case_count": count,
        "primary_pass_count": sum(case["primary_pass"] for case in cases),
        "primary_score": sum(case["primary_score"] for case in cases),
        "primary_max": sum(case["primary_max"] for case in cases),
        "safety_underescalation_count": sum(case["safety_underescalation"] for case in cases),
        "overescalation_count": sum(case["overescalation"] for case in cases),
        "process_pass_count": sum(case["process_pass"] for case in cases),
        "risk_pass_count": sum(case["risk_pass"] for case in cases),
        "handoff_applicable_count": sum(case["handoff_applicable"] for case in cases),
        "handoff_pass_count": sum(
            case["handoff_pass"] for case in cases if case["handoff_applicable"]
        ),
        "goal_applicable_count": sum(case["goal_applicable"] for case in cases),
        "goal_pass_count": sum(case["goal_pass"] for case in cases if case["goal_applicable"]),
        "loop_applicable_count": sum(case["loop_applicable"] for case in cases),
        "loop_pass_count": sum(case["loop_pass"] for case in cases if case["loop_applicable"]),
        "total_tokens": sum(case["tokens"] for case in cases),
        "avg_tokens": sum(case["tokens"] for case in cases) / count if count else 0,
        "avg_duration_seconds": sum(case["duration_seconds"] for case in cases) / count if count else 0,
    }


def build_summary(args: argparse.Namespace, schedule: list[dict], cases: list[dict], complete: bool) -> dict:
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for case in cases:
        grouped[(case["arm"], case["effort"])].append(case)
    return {
        "generated_at": args.date_stamp,
        "experiment": "plain-sol-vs-bmadx-healthy-neutral-v1",
        "complete": complete,
        "runner": {
            "model": args.model,
            "arms": args.arms,
            "efforts": args.efforts,
            "repeat": args.repeat,
            "seed": args.seed,
            "run_label": args.run_label,
            "schedule_case_count": len(schedule),
            "completed_case_count": len(cases),
            "order": "deterministic shuffled interleaving",
        },
        "primary_contract": {
            "framework_neutral": True,
            "bmadx_labels_exposed": False,
            "plain_skill_loaded": False,
            "bmad_dependency": "healthy fixture in BMADX arm only",
            "treatment_setup_verified": "BMADX SKILL.md present; plain skills directory absent",
            "skill_injection_log_note": "Codex does not expose hidden skill injection as a shell read event",
            "score_max_per_case": "4 base checks plus applicable handoff/goal/loop contracts",
        },
        "cells": {
            f"{arm}-{effort}": cell_summary(grouped[(arm, effort)])
            for effort in args.efforts
            for arm in args.arms
        },
        "cases": cases,
    }


def write_checkpoint(path: Path, args: argparse.Namespace, schedule: list[dict], cases: list[dict]) -> None:
    complete = len(cases) == len(schedule)
    path.write_text(json.dumps(build_summary(args, schedule, cases, complete), indent=2) + "\n", encoding="utf-8")


def rescore_cases(cases: list[dict], scenarios: dict[str, dict]) -> None:
    for case in cases:
        stdout = (BENCHMARK_ROOT.parent / case["raw_txt"]).read_text(encoding="utf-8")
        case.update(score_neutral_response(stdout, scenarios[case["scenario"]]))


def run_case(item: dict, spec: dict, home: Path, workdir: Path, args: argparse.Namespace) -> dict:
    task = task_from_scenario(Path(spec["path"]).read_text(encoding="utf-8"))
    prompt = build_neutral_prompt(task, item["arm"])
    command = build_codex_command(
        prompt,
        workdir,
        home,
        model=args.model,
        reasoning=item["effort"],
    )
    started = time.perf_counter()
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        env=benchmark_env(home, "healthy"),
        check=False,
    )
    duration = time.perf_counter() - started
    stdout = result.stdout.rstrip() + "\n"
    stderr = sanitize_stderr(result.stderr.rstrip()) + "\n"
    raw_base = RAW_ROOT / artifact_stem(args.run_label, item)
    raw_base.with_suffix(".txt").write_text(stdout, encoding="utf-8")
    raw_base.with_suffix(".log").write_text(stdout + "\n--- STDERR ---\n" + stderr, encoding="utf-8")
    if result.returncode != 0:
        raise RuntimeError(f"codex exec failed for {artifact_stem(args.run_label, item)}: {stderr.strip()}")
    tokens = parse_token_count(stderr)
    if tokens is None:
        raise RuntimeError(f"codex exec did not report token usage for {artifact_stem(args.run_label, item)}")
    score = score_neutral_response(stdout, spec)
    return {
        "case_id": artifact_stem(args.run_label, item),
        **item,
        "model": args.model,
        "tokens": tokens,
        "duration_seconds": round(duration, 3),
        **score,
        "raw_txt": repo_relative(raw_base.with_suffix(".txt")),
        "raw_log": repo_relative(raw_base.with_suffix(".log")),
    }


def main() -> int:
    args = parse_args()
    scenarios = all_scenarios()
    schedule = build_schedule(scenarios, args.arms, args.efforts, args.repeat, args.seed)
    output_path = summary_path(args.date_stamp, args.run_label)
    cases: list[dict] = []
    if args.resume and output_path.exists():
        previous = json.loads(output_path.read_text(encoding="utf-8"))
        cases = list(previous.get("cases") or [])
        rescore_cases(cases, scenarios)
    completed = {case["case_id"] for case in cases}

    with tempfile.TemporaryDirectory(prefix="bmadx-sol-ab-") as tmpdir:
        root = Path(tmpdir)
        workdir = root / "workspace"
        workdir.mkdir()
        homes = {arm: setup_home(root, arm, args.model) for arm in args.arms}
        if "bmadx" in homes:
            fixture = write_healthy_bmad_fixture(root)
            warmup_profile(homes["bmadx"], "healthy", fixture)
        for index, item in enumerate(schedule, start=1):
            case_id = artifact_stem(args.run_label, item)
            if case_id in completed:
                continue
            print(f"[{index}/{len(schedule)}] {item['arm']} {item['effort']} {item['scenario']}", flush=True)
            cases.append(run_case(item, scenarios[item["scenario"]], homes[item["arm"]], workdir, args))
            write_checkpoint(output_path, args, schedule, cases)

    write_checkpoint(output_path, args, schedule, cases)
    print(json.dumps({"summary_path": repo_relative(output_path), "cases": len(cases)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
