# Plain Sol vs BMADX A/B - 2026-07-12

## Question

Does BMADX with a healthy BMAD dependency improve GPT-5.6 Sol workflow
decisions versus plain Sol at fixed `medium`, `high`, and `xhigh` effort?

## Protocol

- model: `gpt-5.6-sol`
- arms: clean plain Sol and Sol with local BMADX plus a healthy BMAD fixture
- efforts: fixed `medium`, `high`, and `xhigh`
- scenarios: the same 15 task shapes in each cell
- repeats: `2`, producing 30 cases per cell and 180 total model calls
- order: deterministic shuffled interleaving with seed `560712`
- output: one shared framework-neutral JSON contract
- blinding: plain Sol had no skills; neither arm saw X1-X4 labels, expected routes,
  or a precomputed gear
- scoring: exact process and scenario-specific risk, strict schema, grounded
  reasons, and handoff/goal/loop only where the scenario defines reference truth
- raw evidence: 360 `.txt`/`.log` files, plus a checkpointed summary

Artifacts:

- [A/B summary](../benchmark/ab-summary-2026-07-12-gpt-5-6-sol-causal-neutral-v1.json)
- runner: `benchmark/scripts/run_sol_bmadx_ab.py`
- neutral contract: `benchmark/scripts/sol_bmadx_ab_contract.py`

## Results

| Effort | Plain perfect | BMADX perfect | Delta | Plain score | BMADX score | Safety under: plain / BMADX | Token cost | Latency cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `medium` | 22/30 | 27/30 | +16.67 pp | 91.43% | 97.86% | 4 / 2 | +29.46% | +19.85% |
| `high` | 23/30 | 27/30 | +13.33 pp | 92.86% | 97.86% | 4 / 1 | +50.99% | +20.61% |
| `xhigh` | 23/30 | 28/30 | +16.67 pp | 92.86% | 98.57% | 4 / 2 | +28.72% | +14.42% |

Matched primary-score outcomes (`BMADX win / tie / loss`):

- `medium`: `8 / 21 / 1`
- `high`: `4 / 26 / 0`
- `xhigh`: `6 / 24 / 0`

The repeat-level direction was consistent. BMADX improved full-pass count in
both repeats at every effort except one medium matched case where plain scored
higher. Per-effort samples are still small: these directional results are not
treated as a population-level statistical claim.

## What Improved

BMADX's clearest gains were on workflow boundaries rather than easy tasks:

- goal-aware auth cleanup: plain passed 2/6; BMADX passed 6/6,
- onboarding variant: plain passed 0/6; BMADX passed 4/6,
- generic X4-shaped scaffold task: plain passed 0/6; BMADX passed 3/6,
- bounded migration repair loop: plain passed 1/6; BMADX passed 4/6.

Both arms passed all 36 easy `x1`, `x2`, pricing-copy, subscription-billing,
Google-login, and migration-incident decisions. BMADX's value in this suite is
therefore better process calibration and goal/loop discipline, not a universal
gain on every task.

## Decision

Use BMADX for consequential Sol planning when an extra 14-21% latency and
29-51% all-token footer cost is acceptable. The six-cell test supports a
causal claim about the tested bundle: adding BMADX plus a healthy BMAD fixture
improved classification quality on this fixed scenario set.

Keep `high` as the normal Sol planning baseline. Within BMADX, `high` and
`medium` both passed 27/30, while `xhigh` passed 28/30. The one-case xhigh gain
is too small to justify making it default; xhigh also used 6.60% more tokens
and 1.56% more latency than high.

## Limits

- This isolates `plain Sol` from `BMADX + healthy BMAD`; it does not isolate
  BMADX from BMAD. A third `BMADX + degraded/no BMAD` arm is required for that.
- It measures workflow decisions, not implementation quality.
- The scenarios and reference answers are authored by this project and may
  favor its process philosophy even though the response schema is neutral.
- Two repeats expose direction and obvious instability, not broad statistical
  generalization.
- Codex's human-readable token footer is an all-token operational measure, not
  a clean input/output billing decomposition.
- Codex logs the isolated BMADX `CODEX_HOME` and explicit `$bmadx` treatment but
  does not expose hidden skill injection as a shell read event. The treatment
  setup verifies `SKILL.md` exists only in the BMADX home; this is strong setup
  evidence, not direct per-call skill-read telemetry.

## Implementation Benchmark

The next benchmark should use 6-10 small, isolated repositories with hidden,
executable tests. Each task should run through the same six cells and be scored
without framework labels on:

1. hidden test pass rate and regression count,
2. required behavior coverage,
3. unsafe or out-of-scope mutations,
4. diff size and maintainability review,
5. rollback and verification quality,
6. tokens, latency, and retries to green.

Use fresh worktrees, identical starting commits, fixed tool permissions, and a
hard time/token budget. Randomize cell order per task, keep graders blind to the
arm, stop a cell on destructive behavior or budget exhaustion, and report both
intention-to-treat and completed-run outcomes.

## Oracle Consultation

Oracle was attempted with GPT-5.6 Sol Pro using inline context, a minimal
prompt, and finally one 18.1 KB ZIP containing five selected benchmark files.
The UI model selection was verified, and the ZIP uploaded, but all sessions
ended before prompt commit with `turnsCount=0` and `prompt-commit-timeout`.
No Oracle answer was produced or represented as evidence in this protocol.
